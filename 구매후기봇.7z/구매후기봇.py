from discord import user
from discord_components import DiscordComponents, ComponentsBot, Select, SelectOption, Button, ButtonStyle, ActionRow
import discord, sqlite3, datetime, randomstring, os, random
from discord_components.ext.filters import user_filter
import asyncio, requests, json
from datetime import timedelta
from discord_webhook import DiscordEmbed, DiscordWebhook
from discord_buttons_plugin import ButtonType
from asyncio import futures
import time

@bot.event
async def on_ready():
    DiscordComponents(bot)
    print(f"[!] 봇 이름 : {bot.user.name}\n[!] 봇 아이디 : {bot.user.id}\n[!] 참가 중인 서버 : {len(bot.guilds)}개")
    while True:
        await bot.change_presence(activity=discord.Game(f"Roy | {len(bot.guilds)}서버 사용"),status=discord.Status.online)
        await asyncio.sleep(3)

@bot.event
async def on_message(message):
    if message.author.bot:
        return
    
    if message.channel.id == 958297362848174103:
        await message.add_reaction('💗')
        await message.reply("좋은후기 감사합니다💗")
        return

bot.run("")
